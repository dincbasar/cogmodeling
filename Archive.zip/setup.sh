#!/bin/bash

sudo easy_install pip3
pip3 install scipy
pip3 install argparse
pip3 install numpy
pip3 install keras
pip3 install tensorflow
pip3 install Pillow
pip3 install opencv-python

python3 draw.py